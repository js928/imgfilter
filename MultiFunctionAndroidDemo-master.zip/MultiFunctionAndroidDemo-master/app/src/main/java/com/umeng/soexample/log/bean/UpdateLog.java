package com.umeng.soexample.log.bean;

/**
 * Created by wangfei on 2018/1/22.
 */

public class UpdateLog {
    public String name;
    public String date;
    public String content;
}
