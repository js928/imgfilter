package com.umeng.soexample.twitterapi;

import com.umeng.socialize.handler.UMTwitterReceiver;

/**
 * Created by umeng on 2018/11/13.
 */

public class TwitterShareReceiver extends UMTwitterReceiver {

}
