package com.umeng.soexample.log;

/**
 * Created by wangfei on 2018/1/22.
 */

public class UPushLogFrg extends BaseFragment{
    @Override
    public String getFileName() {
        return "upush";
    }
}
