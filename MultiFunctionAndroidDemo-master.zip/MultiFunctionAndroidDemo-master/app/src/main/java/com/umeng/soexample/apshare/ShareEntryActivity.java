package com.umeng.soexample.apshare;

import com.umeng.socialize.media.ShareCallbackActivity;

/**
 * Created by wangfei on 15/11/18.
 */
public class ShareEntryActivity extends ShareCallbackActivity {

}
