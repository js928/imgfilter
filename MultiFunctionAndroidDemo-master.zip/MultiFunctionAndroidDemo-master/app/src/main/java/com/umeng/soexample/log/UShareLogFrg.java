package com.umeng.soexample.log;

/**
 * Created by wangfei on 2018/1/22.
 */

public class UShareLogFrg extends BaseFragment{
    @Override
    public String getFileName() {
        return "ushare";
    }
}